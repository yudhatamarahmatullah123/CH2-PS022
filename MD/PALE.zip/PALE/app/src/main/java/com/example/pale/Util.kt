package com.example.pale

import android.app.Activity
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Build
import android.view.View
import android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine

fun TextView.setGradientTextColor() {
    val textShader: Shader = LinearGradient(
        0f,
        0f,
        0f,
        this.height.toFloat(),
        intArrayOf(Color.parseColor("#0085FF"), Color.parseColor("#000000")),
        null,
        Shader.TileMode.CLAMP
    )
    this.paint.shader = textShader
}

suspend fun View.awaitLayoutChange() = suspendCancellableCoroutine<Unit> { cont ->
    val listener = object : View.OnLayoutChangeListener {
        override fun onLayoutChange(
            view: View?,
            left: Int,
            top: Int,
            right: Int,
            bottom: Int,
            oldLeft: Int,
            oldTop: Int,
            oldRight: Int,
            oldBottom: Int
        ) {
            view?.removeOnLayoutChangeListener(this)
            cont.resumeWith(Result.success(Unit))
        }
    }

    addOnLayoutChangeListener(listener)
    cont.invokeOnCancellation { removeOnLayoutChangeListener(listener) }
}

fun Activity.setStatusBarColor(color: Int, useDarkIcons: Boolean) {
    window.statusBarColor = ContextCompat.getColor(this, color)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        if (useDarkIcons) {
            window.decorView.windowInsetsController?.setSystemBarsAppearance(APPEARANCE_LIGHT_STATUS_BARS, APPEARANCE_LIGHT_STATUS_BARS)
        } else {
            window.decorView.windowInsetsController?.setSystemBarsAppearance(0, APPEARANCE_LIGHT_STATUS_BARS)
        }
    } else {
        if (useDarkIcons) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        } else {
            window.decorView.systemUiVisibility = 0;
        }
    }
}

