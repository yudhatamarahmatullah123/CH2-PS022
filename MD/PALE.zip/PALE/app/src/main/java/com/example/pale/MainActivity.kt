package com.example.pale

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.pale.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var selectedBottomNavIndex : Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        this.setStatusBarColor(R.color.primary_blue, true)

        binding.bnv.setOnNavigationItemSelectedListener {
            when(it.itemId) {
                R.id.menu_live_monitoring -> {
                    changeFragment(LiveMonitoringFragment())
                    selectedBottomNavIndex = it.itemId
                    true
                }
                R.id.menu_notification -> {
                    changeFragment(NotificationFragment())
                    selectedBottomNavIndex = it.itemId
                    true
                }
                R.id.menu_profile -> {
                    changeFragment(ProfileFragment())
                    selectedBottomNavIndex = it.itemId
                    true
                }
                else -> false
            }
        }

        binding.bnv.selectedItemId = savedInstanceState?.getInt("id") ?: R.id.menu_live_monitoring
    }

    private fun changeFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.container, fragment)
            .addToBackStack(null)
            .commit()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("id", selectedBottomNavIndex ?: R.id.menu_live_monitoring)
    }
}
