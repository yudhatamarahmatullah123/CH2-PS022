package com.example.pale

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import org.eclipse.paho.android.service.MqttAndroidClient
import org.eclipse.paho.client.mqttv3.IMqttActionListener
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.IMqttToken
import org.eclipse.paho.client.mqttv3.MqttCallback
import org.eclipse.paho.client.mqttv3.MqttConnectOptions
import org.eclipse.paho.client.mqttv3.MqttException
import org.eclipse.paho.client.mqttv3.MqttMessage

class Mqtt {
    companion object {
        const val TAG = "AndroidMqttClient"
        private const val serverURI = "tcp://34.31.59.23:1883"
        const val suhu = "sensor/NTC/tempInC"
        const val ammonia = "sensor/MQ135/ammonia"
        const val phAir = "sensor/PH/phValue"
        const val katup = "katup"
    }

    private lateinit var mqttClient: MqttAndroidClient

    fun connect(context: Context, callback: (String, String) -> Unit) {
        mqttClient = MqttAndroidClient(context, serverURI, "kotlin_client")
        mqttClient.setCallback(object : MqttCallback {
            override fun messageArrived(topic: String?, message: MqttMessage?) {
                Log.d(TAG, "$message from: $topic")
                callback(topic.toString(), message.toString())
            }

            override fun connectionLost(cause: Throwable?) {
                Log.d(TAG, "Connection lost ${cause.toString()}")
            }

            override fun deliveryComplete(token: IMqttDeliveryToken?) {

            }
        })
        val options = MqttConnectOptions()
        options.userName = "pale"
        options.password = "Pale123!".toCharArray()
        try {
            mqttClient.connect(options, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.d(TAG, "Connection success")

                    subscribe(
                        arrayOf("sensor/NTC/tempInC", "sensor/MQ135/ammonia", "sensor/PH/phValue", "katup"),
                        intArrayOf(1,1,1,1)
                    )
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    exception?.printStackTrace()
                    Log.d(TAG, "Connection failure ${exception.toString()}")
                }
            })
        } catch (e: MqttException) {
            e.printStackTrace()
        }

    }

    fun subscribe(topic: Array<String>, qos: IntArray) {
        try {
            mqttClient.subscribe(topic, qos, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.d(TAG, "Subscribed to $topic")
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    Log.d(TAG, "Failed to subscribe $topic")
                }
            })
        } catch (e: MqttException) {
            e.printStackTrace()
        }
    }

    fun publish(topic: String, payload: String) {
        try {
            val mqttMessage = MqttMessage(payload.toByteArray())
            mqttClient.publish(topic, mqttMessage)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
