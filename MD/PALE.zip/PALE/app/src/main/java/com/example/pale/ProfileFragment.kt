package com.example.pale

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.pale.databinding.FragmentProfileBinding

class ProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding
    private lateinit var sp: SharedPreferences

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentProfileBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        requireActivity().setStatusBarColor(R.color.primary_blue, true)

        sp = requireContext().getSharedPreferences(getString(R.string.app_name),
            AppCompatActivity.MODE_PRIVATE
        )

        initData()

        binding.btnLogout.setOnClickListener {
            requireContext().startActivity(Intent(requireContext(), LoginActivity::class.java))
            requireActivity().finish()
            val editor = sp.edit()
            editor.clear()
            editor.apply()
        }

        binding.btnSetting.setOnClickListener {
            startActivity(Intent(requireContext(), SettingActivity::class.java))
        }

        binding.btnEdit.setOnClickListener {
            startActivity(Intent(requireContext(), EditProfileActivity::class.java))
        }
    }

    private fun initData() {
        val name = sp.getString("name", "Aqil Bahri")
        val imageUri = sp.getString("image", "")

        binding.tvName.text = name.orEmpty()

        if (imageUri.isNullOrEmpty()) {
            binding.ivProfile.setImageResource(R.drawable.baseline_account_circle_24)
        } else {
            val uri = Uri.parse(imageUri)
            Glide.with(requireContext())
                .load(uri)
                .into(binding.ivProfile)
        }
    }

    override fun onResume() {
        super.onResume()
        initData()
    }
}
