package com.example.pale

import android.app.Application
import android.util.Log
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class PaleApp : Application() {

    private val _suhu = MutableStateFlow("")
    val suhu get() = _suhu.asStateFlow()
    private val _phAir = MutableStateFlow("")
    val phAir get() = _phAir.asStateFlow()
    private val _ammonia = MutableStateFlow("")
    val ammonia = _ammonia.asStateFlow()

    override fun onCreate() {
        super.onCreate()
    }
}
