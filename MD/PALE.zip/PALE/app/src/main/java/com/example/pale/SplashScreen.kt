package com.example.pale

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.pale.databinding.ActivitySplashScreenBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashScreen : AppCompatActivity() {

    private lateinit var binding: ActivitySplashScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val nightMode = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE).getBoolean("night_mode", false)
        if (nightMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
        binding = ActivitySplashScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        this.setStatusBarColor(R.color.white, true)

        lifecycleScope.launch {
            binding.tvAppName.awaitLayoutChange()
            binding.tvAppName.setGradientTextColor()

            delay(2000)

            val sp = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE)
            val isLoggedIn = sp.getBoolean("isLoggedIn", false)

            if (isLoggedIn) {
                startActivity(Intent(this@SplashScreen, MainActivity::class.java))
            } else {
                startActivity(Intent(this@SplashScreen, LoginActivity::class.java))
            }

            finish()
        }
    }
}
