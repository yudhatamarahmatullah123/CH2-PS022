package com.example.pale

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import com.example.pale.databinding.FragmentLiveMonitoringBinding
import kotlinx.coroutines.launch

class LiveMonitoringFragment : Fragment() {

    private lateinit var binding: FragmentLiveMonitoringBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentLiveMonitoringBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        requireActivity().setStatusBarColor(R.color.primary_blue, true)
        val mqtt = Mqtt()
        mqtt.connect(requireContext()) { topic, value ->
            when (topic) {
                Mqtt.suhu -> {
                    binding.tvSuhu.text = "${value.toDouble().toInt()}°C"
                    if (value.toDouble() < 25 || value.toDouble() > 30) {
                        binding.cardSuhu.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.holo_red_dark))
                    } else {
                        binding.cardSuhu.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.white))
                    }
                }
                Mqtt.ammonia -> {
                    binding.tvAmonia.text = value
                    if (value.toDouble() > 0.8) {
                        binding.cardAmmonia.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.holo_red_dark))
                    } else {
                        binding.cardAmmonia.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.white))
                    }
                }
                Mqtt.phAir -> {
                    binding.tvPhAir.text = value
                    if (value.toDouble() < 6 || value.toDouble() > 9) {
                        binding.cardPhAir.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.holo_red_dark))
                    } else {
                        binding.cardPhAir.setCardBackgroundColor(ContextCompat.getColor(requireContext(), android.R.color.white))
                    }
                }
            }
        }
    }
}
