package com.example.pale

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import com.bumptech.glide.Glide
import com.example.pale.databinding.ActivityEditProfileBinding

class EditProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditProfileBinding
    private lateinit var sp: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sp = getSharedPreferences(getString(R.string.app_name),
            MODE_PRIVATE
        )

        val isNightMode = sp.getBoolean("night_mode", false)

        if (isNightMode) {
            this.setStatusBarColor(R.color.black, false)
        } else {
            this.setStatusBarColor(R.color.white, true)
        }

        initData()

        val selectImageIntent = registerForActivityResult(ActivityResultContracts.GetContent())
        { uri ->
            Glide.with(this)
                .load(uri)
                .into(binding.ivProfile)

            val editor = sp.edit()
            editor.putString("image", uri.toString())
            editor.apply()
        }

        binding.btnChangeImage.setOnClickListener {
            selectImageIntent.launch("image/*")
        }

        binding.btnBack.setOnClickListener { finish() }
        binding.layoutName.setOnClickListener {
            startActivity(Intent(this, EditNameActivity::class.java))
        }
    }

    private fun initData() {val name = sp.getString("name", "Aqil Bahri")
        val imageUri = sp.getString("image", "")

        binding.tvName.text = name.orEmpty()

        if (imageUri.isNullOrEmpty()) {
            binding.ivProfile.setImageResource(R.drawable.baseline_account_circle_24)
        } else {
            val uri = Uri.parse(imageUri)
            Glide.with(this)
                .load(uri)
                .into(binding.ivProfile)
        }
    }

    override fun onResume() {
        super.onResume()
        initData()
    }
}
