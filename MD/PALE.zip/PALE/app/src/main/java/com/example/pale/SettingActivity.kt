package com.example.pale

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.example.pale.databinding.ActivitySettingBinding

class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_NO || AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_UNSPECIFIED) {
            binding.ivIconDarkMode.setImageResource(R.drawable.ic_sun)
            binding.switchDarkMode.isChecked = false
            this.setStatusBarColor(R.color.white, true)
        } else {
            binding.ivIconDarkMode.setImageResource(R.drawable.ic_moon)
            binding.switchDarkMode.isChecked = true
            this.setStatusBarColor(R.color.black, false)
        }

        binding.switchDarkMode.setOnCheckedChangeListener { compoundButton, isChecked ->
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                binding.ivIconDarkMode.setImageResource(R.drawable.ic_moon)
                editNightMode(true)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                binding.ivIconDarkMode.setImageResource(R.drawable.ic_sun)
                editNightMode(false)
            }
        }

        binding.btnBack.setOnClickListener { finish() }
    }

    private fun editNightMode(nightMode: Boolean) {
        val sp = getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE)
        val editor = sp.edit()
        editor.putBoolean("night_mode", nightMode)
        editor.apply()
    }
}
