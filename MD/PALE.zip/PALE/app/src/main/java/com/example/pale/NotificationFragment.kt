package com.example.pale

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.pale.databinding.FragmentNotificationBinding

class NotificationFragment : Fragment() {

    private lateinit var binding: FragmentNotificationBinding
    private var isSuhuDanger: Boolean = false
    private var isAmmoniaDanger: Boolean = false
    private var isPhAirDanger: Boolean = false
    private val mqtt: Mqtt = Mqtt() // Inisialisasi objek mqtt di sini

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentNotificationBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mqtt.connect(requireContext()) { topic, value ->
            when (topic) {
                Mqtt.suhu -> {
                    if (value.toDouble() < 20 || value.toDouble() > 30) {
                        isSuhuDanger = true
                        binding.tvSuhu.text = "${value.toDouble().toInt()}°C"
                        binding.cardSuhu.visibility = View.VISIBLE
                    } else {
                        isSuhuDanger = true
                        binding.cardSuhu.visibility = View.GONE
                    }
                    checkDanger()
                }
                Mqtt.ammonia -> {
                    if (value.toDouble() >= 0.8) {
                        isAmmoniaDanger = true
                        binding.tvAmonia.text = value
                        binding.cardAmmonia.visibility = View.VISIBLE
                        binding.layoutKatup.visibility = View.VISIBLE
                    } else {
                        isAmmoniaDanger = true
                        binding.cardAmmonia.visibility = View.GONE
                        binding.layoutKatup.visibility = View.GONE
                    }
                    checkDanger()
                }
                Mqtt.phAir -> {
                    if (value.toDouble() < 6 || value.toDouble() > 9) {
                        isPhAirDanger = true
                        binding.tvPhAir.text = value
                        binding.cardPhAir.visibility = View.VISIBLE
                    } else {
                        isPhAirDanger = true
                        binding.cardPhAir.visibility = View.GONE
                    }
                    checkDanger()
                }
                Mqtt.katup -> {
                    // Update status switch berdasarkan payload
                    binding.switchKatup.isChecked = value?.lowercase() == "on"
                    binding.switchKatup.setOnCheckedChangeListener { _, isChecked ->
                        // Kirim perintah ke broker MQTT saat switch diubah
                        val payload = if (isChecked) "on" else "off"
                        mqtt.publish(Mqtt.katup, payload)
                    }
                }
            }
        }
    }

    private fun checkDanger() {
        if (isSuhuDanger || isAmmoniaDanger || isPhAirDanger) {
            showLayoutDanger()
        } else {
            hideLayoutDanger()
        }
    }

    private fun showLayoutDanger() {
        with(binding) {
            layoutTopDanger.visibility = View.VISIBLE
            tvTitle.visibility = View.GONE
            ivNotification.visibility = View.GONE
            tvNotification.visibility = View.GONE
            ivBackground.setImageResource(R.drawable.background_red)
            requireActivity().setStatusBarColor(android.R.color.holo_red_dark, true)
        }
    }

    private fun hideLayoutDanger() {
        with(binding) {
            layoutTopDanger.visibility = View.GONE
            tvTitle.visibility = View.VISIBLE
            ivNotification.visibility = View.VISIBLE
            tvNotification.visibility = View.VISIBLE
            ivBackground.setImageResource(R.drawable.background_blue)
            requireActivity().setStatusBarColor(R.color.primary_blue, true)
        }
    }
}
